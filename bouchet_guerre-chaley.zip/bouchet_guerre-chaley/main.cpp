#include "MyApp.h"

IMPLEMENT_APP(MyApp)
