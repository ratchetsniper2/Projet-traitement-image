#include "MyRotateDialog.h"

MyRotateDialog::MyRotateDialog(wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style) : wxDialog( parent, id, title, pos, size, style){
    SetClientSize(wxSize(200,150));

    wxString __wxRadioBoxChoices_1[3] =
    {
    wxT("90    "),
    wxT("180   "),
    wxT("-90   ")
    };

    m_radioBox = new wxRadioBox(this, wxID_ANY, _("Rotation angle"), wxPoint(16,8), wxSize(175,90), 3, __wxRadioBoxChoices_1, 3, 0, wxDefaultValidator, _T("ID_RADIOBOX1"));
    m_okButton = new wxButton(this, wxID_OK, _("OK"), wxPoint(16,110), wxDefaultSize, 0, wxDefaultValidator, _T("wxID_OK"));
    m_cancelButton = new wxButton(this, wxID_CANCEL, _("Cancel"), wxPoint(104,110), wxDefaultSize, 0, wxDefaultValidator, _T("wxID_CANCEL"));
}

MyRotateDialog::~MyRotateDialog(){
}
